/*----------------------------------------------------------------------------------*/
/*  追踪指定颜色物体，并输出三维坐标                                                  */
/*----------------------------------------------------------------------------------*/

#include <iostream>
#include <sl_zed/Camera.hpp>
#include <opencv2/opencv.hpp>

using namespace sl;
using namespace cv;
using namespace std;

//sl空间到cv空间
cv::Mat slMat2cvMat(sl::Mat& input);

int main(int argc, char **argv) {

    
    //创建相机对象
    Camera zed;

    
    
    //设置相机参数
    InitParameters init_params;
    init_params.camera_resolution = RESOLUTION_HD1080;
    init_params.depth_mode = DEPTH_MODE_PERFORMANCE;
    init_params.coordinate_units = UNIT_METER;
    //init_params.camera_fps = 30; 
    
    
    if (argc > 1) init_params.svo_input_filename.set(argv[1]);
        
    //打开相机
    ERROR_CODE err = zed.open(init_params);
    if (err != SUCCESS) {
        printf("%s\n", toString(err).c_str());
        zed.close();
        return 1; 
    }

    
    

    //设置打开相机后的运行参数
    RuntimeParameters runtime_parameters;
    runtime_parameters.sensing_mode = SENSING_MODE_STANDARD;

    //准备新的图像大小来检索半分辨率图像
    Resolution image_size = zed.getResolution();
    int new_width = image_size.width / 2;
    int new_height = image_size.height / 2;

    //声明三个cv处理的对象    
    cv::Mat kernel, dst;
    kernel = getStructuringElement(MORPH_RECT, Size(5, 5));
    
    //定义两个窗口
    cv::namedWindow("input", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("output", CV_WINDOW_AUTOSIZE);
    
    std::vector<std::vector<Point>> contours;//轮廓
	std::vector<Vec4i> hireachy;//层次
    Rect rect;
	Point2f center;//圆心
	float radius = 20;//半径
    
    while (true) {

        if (zed.grab(runtime_parameters) == SUCCESS) {
		    
		    //sl::Mat depth_image_zed(new_width, new_height, MAT_TYPE_8U_C4);
            //cv::Mat depth_image_ocv = slMat2cvMat(depth_image_zed);
		    
		    //获取zed相机图像（4通道）
		    sl::Mat image_zed(new_width, new_height, MAT_TYPE_8U_C4);
            
            //声明image_zed图像来源           
            zed.retrieveImage(image_zed, VIEW_LEFT, MEM_CPU, new_width, new_height);            
        
            //转换sl空间下的image_zed到cv空间下的image_ocv
            cv::Mat image_ocv = slMat2cvMat(image_zed);
            
            //提取三通道
            std::vector<cv::Mat> a;
            split(image_ocv,a);
            std::vector<cv::Mat> b;
            b.push_back(a[0]);//一通道
            b.push_back(a[1]);//二通道
            b.push_back(a[2]);//三通道
            //cv::Mat c;
            //c=a[3].clone();
            //cout << c <<endl;
            merge(b,image_ocv);//合并三通道
	
/*-----------------------------------------------------------------------------------
  void inRange(InputArray src, InputArray lowerb, InputArray upperb, OutputArray dst);
  src:出入图像;
  lowerb：下边界数组，阈值下限;
  upperb：上边界数组，阈值上限;
  dst：输出图像。
------------------------------------------------------------------------------------*/            
            
            //对图像进行阈值化，通过修改阈值上下限lower=Scalar(*,*,*)，upper=Scalar(*,*,*)来修改追踪“神马”颜色的物体
            cv::inRange(image_ocv, Scalar(0, 80, 80), Scalar(50, 255, 255), dst);
	        	                
	        //开操作
			cv::morphologyEx(dst, dst, MORPH_OPEN, kernel);
			
			//识别物体后跟随
			//获取边界
			cv::findContours(dst, contours, hireachy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE, Point(0, 0));
			//框选面积最大边界
			if (contours.size() > 0)
	  		{
				double maxArea = 0;
				for (int i = 0; i < contours.size(); i++)
				{
					double area = contourArea(contours[static_cast<int>(i)]);
					if (area > maxArea)
					{
						maxArea = area;
						rect = boundingRect(contours[static_cast<int>(i)]);
						minEnclosingCircle(contours[static_cast<int>(i)], center, radius);
				
					}
				}
	  		}
	//矩形框
	//rectangle(frame, rect, Scalar(0, 255, 0), 2);
	
	//圆形框
	circle(image_ocv, Point(center.x, center.y), (int)radius, Scalar(0, 255, 0), 2);
	
	//利用点云图像输出三维坐标
	sl::Mat point_cloud;
	zed.retrieveMeasure(point_cloud, MEASURE_XYZRGBA);
	sl::float4 point3D;
	point_cloud.getValue(center.x, center.y, &point3D);
	float x0 = point3D.x;
	float y0 = point3D.y;
	float z0 = point3D.z;
			
	//输出三维坐标
	cout << "x = " << x0 << "  " << "y = " << y0 << "  " << "z = " << z0 << endl;
	cout << endl;
	//显示输入输出窗口
	imshow("input", image_ocv);
	imshow("output", dst);
	

            cv::waitKey(10);
            
        }
    }
    zed.close();
    return 0;
}

/**
* sl::Mat 和 cv::Mat 之间的转换函数
**/
cv::Mat slMat2cvMat(sl::Mat& input) 
{

    int cv_type = -1;
    switch (input.getDataType()) 
    {
        case MAT_TYPE_32F_C1: cv_type = CV_32FC1; break;
        case MAT_TYPE_32F_C2: cv_type = CV_32FC2; break;
        case MAT_TYPE_32F_C3: cv_type = CV_32FC3; break;
        case MAT_TYPE_32F_C4: cv_type = CV_32FC4; break;
        case MAT_TYPE_8U_C1: cv_type = CV_8UC1; break;
        case MAT_TYPE_8U_C2: cv_type = CV_8UC2; break;
        case MAT_TYPE_8U_C3: cv_type = CV_8UC3; break;
        case MAT_TYPE_8U_C4: cv_type = CV_8UC4; break;
        default: break;
    }

    return cv::Mat(input.getHeight(), input.getWidth(), cv_type, input.getPtr<sl::uchar1>(MEM_CPU));
}


